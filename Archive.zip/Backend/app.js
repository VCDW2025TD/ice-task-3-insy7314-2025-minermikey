// app.js
const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
require('dotenv').config();

const app = express();

// Enable CORS for your frontend
app.use(cors({
  origin: "https://localhost:5173", // change to your frontend origin
  credentials: true
}));

// Parse JSON & CSP reports
app.use(express.json({ type: ["application/json", "application/csp-report"] }));

// Security headers
app.use(helmet());

// Content Security Policy
const cspDirectives = {
  defaultSrc: ["'self'"],
  scriptSrc: ["'self'", "https://apis.google.com"], // allow Google APIs if needed
  styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
  fontSrc: ["'self'", "https://fonts.gstatic.com"],
  imgSrc: ["'self'", "data:"],
  connectSrc: ["'self'", "https://localhost:5000"], // API port
  frameAncestors: ["'none'"],
};

app.use(
  helmet.contentSecurityPolicy({
    useDefaults: true,
    directives: {
      ...cspDirectives,
      "report-uri": ["/csp-report"],
    },
    reportOnly: process.env.NODE_ENV !== "production",
  })
);

// CSP violation reporting
app.post("/csp-report", (req, res) => {
  console.log("CSP Violation Report:", JSON.stringify(req.body, null, 2));
  res.sendStatus(204);
});

// Health check route
app.get("/api/health", (_req, res) => {
  res.json({ ok: true, ts: new Date().toISOString() });
});

// Example auth routes (replace with real ones later)
const authRoutes = require("./routes/authRoutes.js");
const { protect } = require("./middleware/authMiddleware.js");

app.use("/api/auth", authRoutes);

// Example protected route
app.get("/api/protected", protect, (req, res) => {
  res.json({ message: `Welcome, user ${req.user.id}!`, timestamp: new Date() });
});

module.exports = app;
