// // frontend/pages/Home.jsx
// import { Link } from "react-router-dom";

// export default function Home() {
//   return (
//     <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center text-center p-6">
//       {/* Header Section */}
//       <h1 className="text-4xl font-bold text-gray-800 mb-4">
//         Welcome to SecureBlog
//       </h1>
//       <p className="text-lg text-gray-600 max-w-lg mb-8">
//         A secure platform where you can register, log in, and manage your data safely.
//         Built with strong security practices using HTTPS, Helmet, and JWT authentication.
//       </p>

//       {/* CTA Buttons */}
//       <div className="space-x-4">
//         <Link
//           to="/register"
//           className="px-6 py-3 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700 transition"
//         >
//           Register
//         </Link>
//         <Link
//           to="/login"
//           className="px-6 py-3 bg-gray-300 text-gray-800 rounded-lg shadow hover:bg-gray-400 transition"
//         >
//           Login
//         </Link>
//       </div>

//       {/* Features Section */}
//       <div className="mt-12 grid md:grid-cols-3 gap-8 max-w-4xl w-full">
//         <div className="bg-white p-6 rounded-lg shadow hover:shadow-lg transition">
//           <h2 className="text-xl font-semibold text-gray-800">Secure Authentication</h2>
//           <p className="text-gray-600 mt-2">
//             All logins are protected with JWT and encrypted connections for maximum security.
//           </p>
//         </div>
//         <div className="bg-white p-6 rounded-lg shadow hover:shadow-lg transition">
//           <h2 className="text-xl font-semibold text-gray-800">CSP Protection</h2>
//           <p className="text-gray-600 mt-2">
//             Strong Content Security Policies prevent malicious scripts and XSS attacks.
//           </p>
//         </div>
//         <div className="bg-white p-6 rounded-lg shadow hover:shadow-lg transition">
//           <h2 className="text-xl font-semibold text-gray-800">HTTPS by Default</h2>
//           <p className="text-gray-600 mt-2">
//             All communications run over secure HTTPS with SSL certificates.
//           </p>
//         </div>
//       </div>

//       {/* Footer */}
//       <footer className="mt-16 text-gray-500 text-sm">
//         &copy; {new Date().getFullYear()} SecureBlog. All rights reserved.
//       </footer>
//     </div>
//   );
// }
// import React from "react";
// import { Link } from "react-router-dom";
// import "./HomePage.css";

// const Home = () => {
//   return (
//     <div className="home-container">
//       <div className="hero-section">
//         <h1>Welcome to SecureBlog</h1>
//         <p className="subtitle">Your secure blogging platform with advanced security features</p>
        
//         <div className="cta-buttons">
//           <Link to="/register" className="btn btn-primary">
//             Get Started
//           </Link>
//           <Link to="/login" className="btn btn-secondary">
//             Sign In
//           </Link>
//         </div>
//       </div>

//       <div className="features-section">
//         <h2>Why Choose SecureBlog?</h2>
//         <div className="features-grid">
//           <div className="feature-card">
//             <div className="feature-icon">🔒</div>
//             <h3>Secure Authentication</h3>
//             <p>Advanced JWT-based authentication to keep your account safe.</p>
//           </div>
//           <div className="feature-card">
//             <div className="feature-icon">⚡</div>
//             <h3>Lightning Fast</h3>
//             <p>Built with modern technologies for optimal performance.</p>
//           </div>
//           <div className="feature-card">
//             <div className="feature-icon">🛡️</div>
//             <h3>Data Protection</h3>
//             <p>Your data is encrypted and protected at all times.</p>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Home;
// frontend/pages/HomePage.jsx
import React from "react";

const HomePage = () => {
  return (
    <div>
      <h1>Welcome to Talia Security</h1>
      <p>This is the home page.</p>
    </div>
  );
};

export default HomePage;
